package com.demo;

import com.demo.bean.Video;
import com.mongodb.spark.MongoSpark;
import com.mongodb.spark.rdd.api.java.JavaMongoRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.SparkSession;
import org.bson.Document;

public final class MongoSparkCon {

    public static void main(final String[] args) throws InterruptedException {
    /* Create the SparkSession.
     * If config arguments are passed from the command line using --conf,
     * parse args for the values to set.
     */
        SparkSession spark = SparkSession.builder()
                .master("local")
                .appName("MongoSparkConnectorIntro")
                .config("spark.mongodb.input.uri", "mongodb://127.0.0.1/demo.videos")
                .config("spark.mongodb.output.uri", "mongodb://127.0.0.1/demo.videos")
                .getOrCreate();

        // Create a JavaSparkContext using the SparkSession's SparkContext object
        JavaSparkContext jsc = new JavaSparkContext(spark.sparkContext());
        JavaMongoRDD<Document> rdd = MongoSpark.load(jsc);
        System.out.println(rdd.collect().toString());
        // More application logic would go here...

        // Load data and infer schema, disregard toDF() name as it returns Dataset
        Dataset<Row> implicitDS = MongoSpark.load(jsc).toDF();
        implicitDS.printSchema();
        implicitDS.show();

        // Load data with explicit schema
        Dataset<Video> explicitDS = MongoSpark.load(jsc).toDS(Video.class);
        explicitDS.printSchema();
        explicitDS.show();


        // Create the temp view and execute the query
        explicitDS.createOrReplaceTempView("videos");
        Dataset<Row> centenarians = spark.sql("SELECT color FROM videos");
        centenarians.show();

        jsc.close();

    }
}